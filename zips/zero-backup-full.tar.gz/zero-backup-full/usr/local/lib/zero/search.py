import requests
from .core import log_message

def search(term, repos, instance="default"):
    for name, base_url in repos.items():
        print(f"[Zero] Procurando em {name}...")
        try:
            r = requests.get(base_url, timeout=10)
            if r.status_code == 200:
                found = False
                for line in r.text.splitlines():
                    if term in line:
                        print(f" - {line.strip()}")
                        found = True
                if not found:
                    print(f"[Zero] Nenhum pacote encontrado em {name}.")
        except Exception as e:
            print(f"[Zero] Falha ao acessar {name}: {e}")
            log_message(instance, f"Erro de busca em {name}: {e}")
