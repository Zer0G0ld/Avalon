import sys
import json
from .core import get_instance_paths, init_db, show_banner
from .install import install
from .remove import remove
from .update import update
from .search import search
from .info import info

INSTANCE = "default"

def load_repos():
    with open("/etc/zero/repos.json") as f:
        return json.load(f)

def main():
    show_banner()
    if len(sys.argv) < 2:
        print("Uso: zero <install|remove|list|update|search|info> [pacote] [--instance nome]")
        sys.exit(0)

    # Verificar instância
    global INSTANCE
    if "--instance" in sys.argv:
        idx = sys.argv.index("--instance")
        INSTANCE = sys.argv[idx+1]
        del sys.argv[idx:idx+2]

    cache_dir, db_file = get_instance_paths(INSTANCE)
    conn, cursor = init_db(db_file)
    repos = load_repos()

    cmd = sys.argv[1].lower()
    pkg = sys.argv[2] if len(sys.argv) > 2 else None

    if cmd == "install" and pkg:
        install(pkg, conn, cursor, cache_dir, repos, INSTANCE)
    elif cmd == "list":
        print("Pacotes instalados:")
        for row in cursor.execute("SELECT name, version, repo, installed_at FROM packages"):
            print(f" - {row[0]} ({row[1]}) de {row[2]} em {row[3]}")
    elif cmd == "remove" and pkg:
        remove(pkg, conn, cursor, INSTANCE)
    elif cmd == "update":
        update(conn, cursor, cache_dir, repos, INSTANCE)
    elif cmd == "search" and pkg:
        search(pkg, repos, INSTANCE)
    elif cmd == "info" and pkg:
        info(pkg, cursor)
    else:
        print(f"[Zero] Comando inválido ou faltando argumentos.")

if __name__ == "__main__":
    main()
