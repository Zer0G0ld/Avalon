import os
import sqlite3
import datetime

# Define instância padrão
INSTANCE = os.environ.get("ZERO_INSTANCE", "default")

# Paths automáticos para a instância
BASE_CACHE_DIR = f"/var/cache/zero/{INSTANCE}"
BASE_DB_FILE = f"/var/lib/zero/{INSTANCE}/installed.db"

# Cria pastas automaticamente
os.makedirs(BASE_CACHE_DIR, exist_ok=True)
os.makedirs(os.path.dirname(BASE_DB_FILE), exist_ok=True)

def get_instance_paths(instance=None):
    """Retorna os paths de cache e DB para a instância"""
    inst = instance if instance else INSTANCE
    cache = f"/var/cache/zero/{inst}"
    db = f"/var/lib/zero/{inst}/installed.db"
    os.makedirs(cache, exist_ok=True)
    os.makedirs(os.path.dirname(db), exist_ok=True)
    return cache, db

def init_db(db_file=None):
    """Inicializa o banco de dados e retorna conexão e cursor"""
    dbf = db_file if db_file else BASE_DB_FILE
    conn = sqlite3.connect(dbf)
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS packages (
        name TEXT PRIMARY KEY,
        version TEXT,
        repo TEXT,
        installed_at TEXT
    );
    """)
    conn.commit()
    return conn, c

def is_root():
    """Verifica se o usuário é root"""
    return os.geteuid() == 0

def show_banner():
    """Exibe banner do Zero"""
    print(f"\n🌀 Zero Package Manager v0.2a by Zer0 (instância: {INSTANCE})\n")
