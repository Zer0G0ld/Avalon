def info(pkg, cursor):
    cursor.execute("SELECT * FROM packages WHERE name=?", (pkg,))
    row = cursor.fetchone()
    if row:
        print(f"Pacote: {row[0]}\nVersão: {row[1]}\nRepo: {row[2]}\nInstalado em: {row[3]}")
    else:
        print(f"[Zero] Pacote {pkg} não está instalado.")
