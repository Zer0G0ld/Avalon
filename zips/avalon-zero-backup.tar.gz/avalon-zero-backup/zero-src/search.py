import requests

def search(term, repos):
    for name, base_url in repos.items():
        print(f"[Zero] Procurando em {name}...")
        try:
            r = requests.get(base_url, timeout=10)
            if r.status_code == 200:
                for line in r.text.splitlines():
                    if term in line:
                        print(f" - {line.strip()}")
        except Exception as e:
            print(f"[Zero] Falha ao acessar {name}: {e}")
