from .core import is_root

def remove(pkg, conn, cursor):
    if not is_root():
        print("[Zero] Você precisa ser root para remover pacotes.")
        return
    cursor.execute("SELECT name FROM packages WHERE name=?", (pkg,))
    if not cursor.fetchone():
        print(f"[Zero] Pacote {pkg} não está instalado.")
        return
    cursor.execute("DELETE FROM packages WHERE name=?", (pkg,))
    conn.commit()
    print(f"[Zero] Pacote {pkg} removido (registro).")
