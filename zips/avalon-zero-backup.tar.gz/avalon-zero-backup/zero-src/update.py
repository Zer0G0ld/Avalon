from .install import install

def update(conn, cursor, cache_dir, repos, pkg=None):
    if pkg:
        install(pkg, conn, cursor, cache_dir, repos)
    else:
        print("[Zero] Atualizando todos os pacotes...")
        for row in cursor.execute("SELECT name FROM packages"):
            install(row[0], conn, cursor, cache_dir, repos)
