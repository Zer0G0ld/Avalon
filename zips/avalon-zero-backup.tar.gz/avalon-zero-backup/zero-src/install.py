import os, shutil, requests, datetime
from .core import is_root

def install(pkg, conn, cursor, cache_dir, repos):
    if not is_root():
        print("[Zero] Você precisa ser root para instalar pacotes.")
        return

    for name, base_url in repos.items():
        pkg_url = f"{base_url}{pkg}-latest-x86_64.pkg.tar.zst"
        try:
            print(f"[Zero] Baixando {pkg} de {name}...")
            r = requests.get(pkg_url, stream=True, timeout=20)
            if r.status_code == 200:
                local_path = os.path.join(cache_dir, f"{pkg}.pkg.tar.zst")
                with open(local_path, "wb") as f:
                    shutil.copyfileobj(r.raw, f)
                print(f"[Zero] Extraindo {pkg}...")
                res = os.system(f"tar -I zstd -xf {local_path} -C /")
                if res != 0:
                    print("[Zero] Erro ao extrair o pacote.")
                    return
                cursor.execute(
                    "INSERT OR REPLACE INTO packages VALUES (?,?,?,?)",
                    (pkg, "latest", name, datetime.datetime.now().isoformat())
                )
                conn.commit()
                print(f"[Zero] Pacote {pkg} instalado com sucesso.")
                return
        except Exception as e:
            print(f"[Zero] Falha ao baixar de {name}: {e}")
    print(f"[Zero] Pacote {pkg} não encontrado em nenhum repositório.")
