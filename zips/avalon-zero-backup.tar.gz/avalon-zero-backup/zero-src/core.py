import os
import sqlite3
import datetime

def get_instance_paths(instance):
    base_cache = f"/var/cache/zero/{instance}"
    base_db = f"/var/lib/zero/{instance}/installed.db"
    os.makedirs(base_cache, exist_ok=True)
    os.makedirs(os.path.dirname(base_db), exist_ok=True)
    return base_cache, base_db

def init_db(db_file):
    conn = sqlite3.connect(db_file)
    c = conn.cursor()
    c.execute("""
    CREATE TABLE IF NOT EXISTS packages (
        name TEXT PRIMARY KEY,
        version TEXT,
        repo TEXT,
        installed_at TEXT
    );
    """)
    conn.commit()
    return conn, c

def is_root():
    return os.geteuid() == 0

def show_banner():
    print("\n🌀 Zero Package Manager v0.2a by Zer0\n")
